
from tabulate import tabulate
import mysql.connector

def Admin(cursor,cnx):
    while(True):
        print("---------------- Admin LOGIN ----------------")
        print("To return to previous page, give customer id and password = -1")
        try : 
            print("Admin ID : ")
            Admin_id = int(input())
            print("Pasword : ")
            Password  = int(input())
            if (Admin_id==-1 and Password==-1):
                return
            if (Admin_id==1 and Password == 1):
                print("Admin ID and password are correct.")
                break
                # Do other actions if customer ID and password are correct
            else:
                print("Admin ID and password are incorrect.")
            # result.close()
        except ValueError :
            print("Invalid Input")
    cursor.close()
    cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                            host='localhost',
                            database='buyit')

    # Create a cursor object
    cnx.autocommit = True
    cursor = cnx.cursor()
    while(True):
        print("======= ADMIN MODE =======")
        print("")
        print("1) ADD ITEM")
        print("2) VIEW EMPLOYEE")
        print("3) VIEW PRODUCT")
        print("4) Delete Product")
        print("5) Enter Supplier Details.")
        print("6) GO BACK TO MENU")

        choice = int(input("Enter : "))
        if (choice == 1):
            name=input("Enter product name: ")
            rprice=int(input("Enter retail price: "))
            wprice=int(input("Enter wholesale price: "))
            rating=int(input("Enter product rating: "))
            category=int(input("Enter Category ID: "))
            param=(name,rprice,wprice,rating,category,1)
            query=("""insert into product (product_name, retailPrice, wholesalePrice, product_rating, category_id, employee_id) values (%s, %s, %s, %s, %s, %s);""")
            cursor.execute(query,param)
            myresult = cursor.fetchall()
        elif (choice == 2):
            query=("""SELECT * FROM employee;""")
            cursor.execute(query)
            myresult = cursor.fetchall()
            print(tabulate(myresult, headers=cursor.column_names))
            # myresult.close(
            print("=========================================")
            
        elif (choice == 3):
            cursor.execute("""select * from product order by product_id;""")
            myresult = cursor.fetchall()

            print(tabulate(myresult, headers=cursor.column_names))
            # myresult.close(
            print("=========================================")
        elif (choice == 4):
            pr_id = int(input("Enter the product_id to delete : "))
            param = (pr_id,pr_id,pr_id,pr_id,pr_id,pr_id)
            cursor2 = cnx.cursor()
            cnx.autocommit = False
            query = ("""
                start transaction ;
                delete from cart_contains where product_id=%s;
                delete from ordered_product where product_id = %s;
                delete from has_warehouse_product where product_id=%s;
                delete from supplier_supplies_product where product_id=%s;
                delete from manager_buy_product where product_id=%s;
                delete from product where product_id=%s;
                commit;
            """)
            cnx.autocommit = True
            cursor2.execute(query,param)
            myresult = cursor2.fetchall()
            cursor2.close()
        if (choice==5):
            first = input("Enter the first name : ")
            middle = input("Enter the middle name : ")
            last = input("Enter the last name : ")
            phone_number = input("Enter the phone Number : ")
            state = input("Enter the state Name : ")
            city  = input("Enter the city name : ")
            pin = input("Enter the pin : ")
            pr_id = int(input("Enter the product Id it deliver : "))
            param = (first,middle,last,phone_number,state,city,pin,pr_id)
            query = ("""
            start transaction;
            insert into supplier (first_name, middle_name, last_name, phone_number, state_name, city_name,
            pin_code, employee_id) values (%s, %s, %s, %s, %s, %s,%s, 1);

            insert into supplier_supplies_product (product_id, supplier_id) values (%s, (select distinct last_insert_id() from supplier));
            commit;
            """)
            cursor.execute(query,param)
        if (choice == 6):
            return
        cursor.close()
        cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                              host='localhost',
                              database='buyit')

        # Create a cursor object
        cnx.autocommit = True
        cursor = cnx.cursor()


            