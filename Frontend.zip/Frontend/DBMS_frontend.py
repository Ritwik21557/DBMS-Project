import mysql.connector
from  User_end import Customer
from Admin_end import Admin
from Manager_end import Manager
from Delivery_Exc_end import Delivery_Executive

# Establish a connection to the database
cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                              host='localhost',
                              database='buyit')

# Create a cursor object
cursor = cnx.cursor()
cnx.autocommit = True


while(True):
    print("---------------- Welcom to Buyit ----------------")

    print("======= MENU =======")
    print("")
    print("1) Admin")
    print("2) Customer")
    print("3) Manager")
    print("4) Delivery Executive")
    print("5) Exit")

    print("--------------------------------------------------")
    print("Enter : ")
    inp = -1
    try : 
        inp = int(input())
        
    except ValueError : 
        print("Invalid input")
    
    print("--------------------------------------------------")
    if (inp==1):
        Admin(cursor,cnx)
    if (inp==2):
        Customer(cursor,cnx)
    if (inp == 3):
        Manager(cursor,cnx)
    if (inp == 4):
        Delivery_Executive(cursor,cnx)
    if (inp==5):
        break


# Close the cursor and database connection
cursor.close()
cnx.close()
