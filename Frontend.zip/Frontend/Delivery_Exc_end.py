
from tabulate import tabulate
import mysql.connector
def Delivery_Executive(cursor,cnx):
    employee_id = int(input("Enter the employee_id : "))
    warehouse_id = int(input("Enter the warehouse_id : "))

    cursor.close()
    cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                            host='localhost',
                            database='buyit')

    # Create a cursor object
    cnx.autocommit = True
    cursor = cnx.cursor()

    while(True):
        print("======= MANAGER MODE =======")
        print("")
        print("1) Get Orders assigned to you")
        print("2) GO BACK TO MENU")

        choice = int(input("Enter  : "))

        if (choice == 1):
            param = (warehouse_id,employee_id,employee_id)
            query=(
                """
                select customer.customer_id,customer.first_name,customer.phone_number,`order`.order_id,warehouse.warehouse_id,delivery_executive.employee_id from warehouse,delivery_executive,`order`,customer
                where %s = warehouse.warehouse_id and `order`.warehouse_id = warehouse.warehouse_id
                and `order`.employee_id = %s and delivery_executive.employee_id = %s and `order`.customer_id = customer.customer_id ;
                """

                )
            cursor.execute(query,param)
            myresult=cursor.fetchall()
            print(tabulate(myresult, headers=cursor.column_names))
        elif (choice == 2):
            return 
        cursor.close()
        cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                                host='localhost',
                                database='buyit')

        # Create a cursor object
        cnx.autocommit = True
        cursor = cnx.cursor()