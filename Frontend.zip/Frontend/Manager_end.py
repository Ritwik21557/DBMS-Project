from tabulate import tabulate
import mysql.connector
def Manager(cursor,cnx):
    warehouse_id = int(input("Warehouse_id :"))
    employee_id = int(input("Employee_ID : "))

    cursor.close()
    cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                            host='localhost',
                            database='buyit')

    # Create a cursor object
    cnx.autocommit = True
    cursor = cnx.cursor()
    while(True):
        print("======= MANAGER MODE =======")
        print("")
        print("1) ORDER DETAILS")
        print("2) View Available Products")
        print("3) SUPPLIER DETAILS")
        print("4) See customers related to your warehouse")
        print("5) which order is supplied by which delivery executive.")
        print("6) GO BACK TO MENU")

        choice = int(input("Enter : "))

        if (choice == 1):
            param = (warehouse_id,)
            # manager can see details of all the orders and which delivery executive is delivering it.
            query=(
            """
            select `order`.warehouse_id,`order`.order_id,`order`.employee_id,customer.customer_id,customer.first_name, customer.middle_name,customer.last_name, customer.phone_number, customer.house_number, customer.pin_code 
            from customer inner join `order` on `order`.customer_id = customer.customer_id inner join warehouse on warehouse.warehouse_id=`order`.warehouse_id where `order`.warehouse_id = %s;

            """)
            cursor.execute(query,param)
            myresult=cursor.fetchall()
            print(tabulate(myresult, headers=cursor.column_names))
            print("=========================================")
        elif (choice == 2):
            param = (warehouse_id,)
            query=(
                    """
                    select * from has_warehouse_product where has_warehouse_product.warehouse_id=%s
                    """
                    )
            cursor.execute(query,param)
            myresult=cursor.fetchall()
            print(tabulate(myresult, headers=cursor.column_names))
        elif (choice == 3):
            # param  = (employee_id,)
            # query=(

            # """
            # select employee.employee_id, employee.first_name, employee.middle_name,  employee.last_name, warehouse.warehouse_id,
            # manager_buy_product.supplier_id,
            # manager_buy_product.product_id from employee inner join manager on 
            # employee.employee_id = manager.employee_id   inner join warehouse on
            # manager.warehouse_id = warehouse.warehouse_id inner join manager_buy_product on
            # manager.employee_id = manager_buy_product.employee_id 
            # where employee.employee_id = %s;


            # """)
            pr_id = int(input("Enter the ID of the Product : "))
            param = (pr_id,)
            query = ("""
                        select supplier.supplier_id,first_name,middle_name,last_name ,phone_number from supplier inner join 
                        supplier_supplies_product on  supplier.supplier_id = supplier_supplies_product.supplier_id  where product_id = %s;
            
            """)

            cursor.execute(query,param)
            myresult=cursor.fetchall()
            print(tabulate(myresult, headers=cursor.column_names))

            print("=========================================")
        elif (choice == 4):
            param = (warehouse_id,)
            query = ("""
                select customer_id,customer.first_name,customer.last_name,customer.phone_number from 
                customer inner join warehouse on warehouse.warehouse_id = customer.warehouse_id where warehouse.warehouse_id = %s;
                    """)
            cursor.execute(query,param)
            myresult=cursor.fetchall()
            print(tabulate(myresult, headers=cursor.column_names))
        elif (choice == 5):
            param = (warehouse_id,)
            query=(
                """
                select `order`.order_id,warehouse.warehouse_id,delivery_executive.employee_id from warehouse,delivery_executive,`order`
                where delivery_executive.warehouse_id = warehouse.warehouse_id and `order`.warehouse_id = warehouse.warehouse_id
                and `order`.employee_id = delivery_executive.employee_id and warehouse.warehouse_id = %s
                group by `order`.order_id,warehouse.warehouse_id,delivery_executive.employee_id ;
                """
                )
            cursor.execute(query,param)
            myresult=cursor.fetchall()
            print(tabulate(myresult, headers=cursor.column_names))
        elif (choice==6):
            return
        cursor.close()
        cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                                host='localhost',
                                database='buyit')

        # Create a cursor object
        cnx.autocommit = True
        cursor = cnx.cursor()
        
