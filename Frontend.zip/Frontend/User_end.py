from tabulate import tabulate
import mysql.connector
from datetime import date
from datetime import datetime

def Customer(cursor,cnx):
    cursor.close()
    cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                            host='localhost',
                            database='buyit')

    # Create a cursor object
    cnx.autocommit = True
    cursor = cnx.cursor()
    while(True):
        print("---------------- Customer LOGIN ----------------")
        print("To return to previous page, give customer id and password = -1")
        try : 
            print("Customer ID : ")
            Customer_id = int(input())
            print("Pasword : ")
            Password  = input()
            if (Customer_id==-1 and Password==-1):
                return
            query = ("select * from customer where customer_id = %s and password = %s")
            parameter = (Customer_id,Password)
            cursor.execute(query,parameter)
            result = cursor.fetchall()
            if result:
                print("Customer ID and password are correct.")
                break
                # Do other actions if customer ID and password are correct
            else:
                print("Customer ID and password are incorrect.")
            # result.close()
        except ValueError :
            print("Invalid Input")

    # finding cart_id 
    param = (Customer_id,)
    query = ("""select cart_id from cart where cart.customer_id=%s;""")
    # cursor.execute("""select cart_id from cart where cart.customer_id=Customer_id;""")
    cursor.execute(query,param)
    a=cursor.fetchall()
    cart_id = a[0][0]

    # finding warehouse_id
    param = (Customer_id,)
    query = ("""select warehouse_id from customer where customer_id = %s""")
    cursor.execute(query,param)
    b = cursor.fetchall()
    warehouse_id = b[0][0]
    # b.close()
    cursor.close()
    cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                            host='localhost',
                            database='buyit')

    # Create a cursor object
    cnx.autocommit = True
    cursor = cnx.cursor()

    while(True):
        print("======= USER MODE =======")
        print("")
        print("1) View Items")
        print("2) View Cart")
        print("3) Add items to Cart")
        print("4) Place order")
        print("5) Remove Items from Cart")
        print("6) See previously placed orders")
        print("7) delete order")
        print("8) GO BACK TO MENU")

        choice=int(input("ENTER YOUR CHOICE: "))

        if (choice == 1):
            cursor.execute("""select * from product order by product_id;""")
            myresult = cursor.fetchall()

            # for x in myresult:
            #     print(x)

            print(tabulate(myresult, headers=cursor.column_names))
            # myresult.close(
            print("=========================================")

        elif (choice == 2):
            query = ("select distinct product_name, cart_contains.count,cart_contains.product_id from product, cart_contains ,cart,customer where cart.customer_id = %s and customer.password = %s and cart_contains.cart_id = cart.cart_id and product.product_id = cart_contains.product_id")
            cursor.execute(query,parameter)
            result = cursor.fetchall()

            print(tabulate(result, headers=cursor.column_names))
            # result.close()
            print("=========================================")
        elif(choice == 3):
            param = (Customer_id,)
            query = ("""select cart_id from cart where cart.customer_id=%s;""")
            # cursor.execute("""select cart_id from cart where cart.customer_id=Customer_id;""")
            cursor.execute(query,param)
            a=cursor.fetchall()
            cart_id = a[0][0]
            list_of_prducts_to_insert={}
            while(True):
                prod=int(input("Enter product id: "))
                count=int(input("Enter the count: "))
                list_of_prducts_to_insert[prod]=count
                ch=input("More y/n")
                if(ch=="n"):
                    break
            for i,j in list_of_prducts_to_insert.items():
                param = (cart_id,i,j)
                query = ("""insert into cart_contains (cart_id, product_id, count) values (%s,%s,%s);""")
                cursor.execute(query,param)

        elif (choice == 4):
            param = (Customer_id,)
            query = ("select cart_value from cart where customer_id = %s;")
            cursor.execute(query,param)

            cart_value = cursor.fetchall()[0][0]
            cursor.nextset()
            print("The value of cart is : ", cart_value)

            ch = input("Do you want to make payment (y/n) : ")
            if (ch=='y'):
                today = date.today()
                formatted_date = today.strftime("%Y-%m-%d")
                now = datetime.now()
                formatted_time = now.strftime("%H:%M:%S")
                param = (cart_value,warehouse_id,cart_id,formatted_date,formatted_time,Customer_id,warehouse_id,warehouse_id,cart_id,cart_id)
                query = ("""
                            start transaction;
                            insert into payment (amount, payment_mode, date, time) values (%s, 1, '2022-03-16', '5:30');
                            
                            update has_warehouse_product inner join cart_contains on cart_contains.product_id = has_warehouse_product.product_id 
                            set has_warehouse_product.count = has_warehouse_product.count - cart_contains.count where has_warehouse_product.warehouse_id = %s and
                            cart_contains.cart_id = %s;


                            insert into `order` (order_date, delivery_time, customer_id, payment_id, warehouse_id, employee_id) values (%s, %s, %s,
                            (select distinct last_insert_id() from payment), %s,  (select employee_id from delivery_executive where warehouse_id = %s limit  1));

                            insert into ordered_product (order_id, product_id) select `order`.order_id,cart_contains.product_id 
                            from cart_contains,`order` where cart_contains.cart_id = %s and `order`.order_id = (select distinct last_insert_id() from `order`);


                            delete from cart_contains where cart_id = %s;




                            commit;
                            """)
                cursor.execute(query,param)
        elif (choice == 5):
            pr_id = int(input("Enter the ID of the product to delete : "))
            param = (cart_id,pr_id)
            query = ("delete from cart_contains where cart_id = %s and product_id = %s;")
            cursor.execute(query,param)

        elif (choice==6):
            param = (Customer_id,)
            query = ("select * from `order` where customer_id = %s;")
            cursor.execute(query,param)
            result = cursor.fetchall()

            print(tabulate(result, headers=cursor.column_names))
            print("=========================================")
        elif (choice == 7):
            order_id  = int(input("Enter the ID of the order to delete : "))
            param = (order_id,order_id)
            query = ("""
                        start transaction;
                        delete from ordered_product where order_id  = %s;
                        delete from `order` where order_id = %s;
                        commit;
                    """)
            cursor.execute(query,param)
        elif (choice == 8):
            return 
        
        cursor.close()
        cnx = mysql.connector.connect(user='root', password='!ArwE80!',
                              host='localhost',
                              database='buyit')

        # Create a cursor object
        cnx.autocommit = True
        cursor = cnx.cursor()